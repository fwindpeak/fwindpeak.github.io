			=======================
			  MadEdit v0.1.2 Beta
			=======================
About:
-----
MadEdit is a cross-platform Text/Hex Editor written in C++ & wxWidgets.
MadEdit supports many useful functions, e.g. SyntaxHighlightings, WordWraps, 
Encodings, Column/Hex Modes, and a Plugin system(not work yet).
In HexMode, MadEdit can open large files which size is up to 32GB (INT_MAX*16).


Supported Platforms:
-------------------
A. Linux (__WXGTK__):
   a. GNU C++ 3.x/4.x:
      Required Libraries to compile:
      1. wxWidgets-2.6.1 or later with Unicode enabled
      2. Boost.Regex-1.3.3 or later

B. MS Windows (__WXMSW__):
   a. MinGW32/GNU C++ 3.x (Dev-C++):
      Required Libraries to compile:
      1. STLport-4.6-0301
      2. wxWidgets-2.6.1 or later with Unicode enabled (must compile with STLport)
      3. Boost.Regex-1.3.3 or later (must compile with STLport)
      4. libunicows: it's optional for WinNT/XP, but required under Win98
   b. Visual C++ 7.1 (VS.Net 2003):
      Required Libraries to compile:
      1. wxWidgets-2.6.1 or later with Unicode enabled
      2. Boost.Regex-1.3.3 or later
      3. libunicows: it's optional for WinNT/XP, but required under Win98


Syntax files, Locale files and Settings:
---------------------------------------
  Syntax files: in the path $(MadEditConfigPath)/syntax/
  Locale files: in the path $(MadEditConfigPath)/locale/
  
  $(MadEditConfigPath) are the one of below paths:
    1. MadEdit execution file directory : Windows and Linux
    2. $(HOME)/.madedit/ : Linux
    3. /etc/madedit/ : Linux
  
  If MadEdit does not find any files in those paths, 
  MadEdit can also execute standalone by using default settings.
  
  If you are under Win98, you must get unicows.dll from MS's website:
  http://www.microsoft.com/downloads/details.aspx?FamilyId=73BA7BD7-ED06-4F0D-80A4-2A7EEAEE17E2&displaylang=en
  
  When MadEdit ends it's work, MadEdit will save the settings to
    1. $(HOME)/.madedit/madedit.cfg: Linux
    2. $(MadEdit execution file directory)/MadEdit.cfg: Windows
  And FontWidth.dat will also be saved to the same path.
  FontWidth.dat is Cache of Font-Width-Data, it can speed-up MadEdit a lot.

  In Win32 platform, MadEdit will ask user to add "MadEdit" to the Right-Click-Menu of Explorer,
  if the answer is YES, it will write a Registry-Key to "HKEY_CLASSES_ROOT\*\shell\MadEdit\command".


ChangeLogs:
----------
v0.1.2:
1.fixed several bugs.
2.added Replace Text/Hex functions.
3.added some fine improvements

v0.1.1:
  fixed some bugs.
  added RightClick Popup Menu.
  added new syntax files.
  added FindPrevious & FindHexNext/Previous functions.
  changed ShortCuts of Text/Column/HexMode to Alt-1, Alt-2, Alt-3.

v0.1:
  added Edit & Search functions.

v0.0.9:
  Preview & AlphaTest version.


License:
-------
MadEdit is released under the GNU General Public License.


Auther:
------
madedit <madedit@gmail.com>


Links:
-----
MadEdit: http://sourceforge.net/projects/madedit/
wxWidgets: http://www.wxwidgets.org/
Boost.Regex: http://www.boost.org/libs/regex/doc/index.html
STLport: http://www.stlport.org/
libunicows: http://libunicows.sourceforge.net/
