syntax_pas.syn

(* Delphi/Pascal syntax *)
