syntax_java.syn

/* Java syntax */
