syntax_cpp.syn

/* C++ syntax */
