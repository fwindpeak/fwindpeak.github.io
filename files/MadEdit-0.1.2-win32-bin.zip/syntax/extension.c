syntax_cpp.syn

/* C/C++ syntax */
